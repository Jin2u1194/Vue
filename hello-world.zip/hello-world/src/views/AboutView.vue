<template>
  <div class="about">
    <h1>This is Subpage</h1>
    <Jin cont="나는 누구인가?" />
  </div>
</template>

<script>
import Jin from "@/components/Jin.vue";

export default {
  components: {
    Jin,
  },
};
</script>
