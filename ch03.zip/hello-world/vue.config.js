const { defineConfig } = require("@vue/cli-service");
//const { turn } = require("core-js/core/array");
module.exports = defineConfig({
  transpileDependencies: false,
  lintOnSave: false,
});
