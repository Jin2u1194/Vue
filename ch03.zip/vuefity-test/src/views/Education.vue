<template>
  <div>
    <h1>Education</h1>
  </div>
</template>
